library(RSVP)
library(sf)
library(dplyr)
library(tidyr)
library(ggplot2)

dir_out <- file.path("C:/Projects/SVIHM/2024_PRMS/TestRun_0802/PRMS/")

#-------------------------------------------------------------------------------------------------#
# Read in PRMS Model Output Files  ------------------------------------------------------
read_and_process_list <- function(file_path, data_types, skip=1, sep=",") {

  # Read in
  readlist <- scan(file_path, skip=skip, sep=sep, what=data_types)

  # Naming elements in the list
  names(readlist) <- c("Date", sprintf("C%d", seq_along(readlist)[-1]))

  # Drop elements where all values are zero
  readlist <- readlist[sapply(readlist, function(x) any(x != 0))]

  # Convert the list to a data frame
  readlist <- as.data.frame(readlist, stringsAsFactors = FALSE)
  readlist$Date <- as.Date(readlist$Date)

  # Make long (takes a while)
  readlist <- readlist %>%
    gather(key = "id", value = "value", -Date) %>%
    mutate(id = as.numeric(sub("C", "", id)))

  return(readlist)
}

#TODO move to somewhere in SVIHM/RSVP
dir_prms <- 'C:/Projects/SVIHM/2024_PRMS/TestRun_0802/PRMS/'

prms_types <- list("")
prms_types <- append(prms_types, numeric(363321))

prms_rech <- read_and_process_list(file.path(dir_prms,'nhrout.txtrecharge_monthly.csv'), prms_types)
# prms_gwin <- read_and_process_list(file.path(dir_prms,'nhrout.txtgwres_in_monthly.csv'), prms_types)
# prms_flow <- read_and_process_list(file.path(dir_prms,'nhrout.txtgwres_flow_monthly.csv'), prms_types)
# prms_sink <- read_and_process_list(file.path(dir_prms,'nhrout.txtgwres_sink_monthly.csv'), prms_types)

# Limit dates
prms_rech[prms_rech]

#-------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------#
# Read in Shapefiles ------------------------------------------------------

#TODO move to somewhere in SVIHM/RSVP
dir_shp <- 'C:/Users/lelan/Box/Research/Scott Valley/GIS'

catchments <- read_sf(file.path(dir_shp, 'PRMS/watershed_FJ.shp'))
prms_catchments <- read_sf(file.path(dir_shp, 'PRMS/PRMS_Grid_ScottWatershedOutsideSVIHM_catchments.shp'))

#-------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------#
# Aggregate PRMS values to catchments monthly -----------------------------

prms_rech <- merge(prms_rech, st_drop_geometry(prms_catchments[,c('HRU_ID','SubId')]), by.x = 'id', by.y='HRU_ID', all=F)
prms_rech$m3m <- (prms_rech$value*0.0254) * (100*100) # inches to meters, times cell size (100m x 100m) = m^3
catch_rech <- prms_rech %>%
  group_by(SubId, Date) %>%
  summarize(total_m3m = sum(m3m))

# prms_gwin <- merge(prms_gwin, st_drop_geometry(prms_catchments[,c('id','SubId')]), by = "id", all=F)
# prms_gwin$m3m <- (prms_gwin$value*0.0254) * (100*100) # inches to meters, times cell size (100m x 100m) = m^3
# catch_gwin <- prms_gwin %>%
#   group_by(SubId, Date) %>%
#   summarize(total_m3m = sum(m3m))
#
# prms_flow <- merge(prms_flow, st_drop_geometry(prms_catchments[,c('id','SubId')]), by = "id", all=F)
# prms_flow$m3m <- (prms_flow$value*0.0254) * (100*100) # inches to meters, times cell size (100m x 100m) = m^3
# catch_flow <- prms_flow %>%
#   group_by(SubId, Date) %>%
#   summarize(total_m3m = sum(m3m))
#
# prms_sink <- merge(prms_sink, st_drop_geometry(prms_catchments[,c('id','SubId')]), by = "id", all=F)
# prms_sink$m3m <- (prms_sink$value*0.0254) * (100*100) # inches to meters, times cell size (100m x 100m) = m^3
# catch_sink <- prms_sink %>%
#   group_by(SubId, Date) %>%
#   summarize(total_m3m = sum(m3m))

# Merge into the catchment shapefile
catch_rech <- merge(catchments, catch_rech, by='SubId', all.x=T)
# catch_gwin <- merge(catchments, catch_gwin, by='SubId', all.x=T)
# catch_flow <- merge(catchments, catch_flow, by='SubId', all.x=T)
# catch_sink <- merge(catchments, catch_sink, by='SubId', all.x=T)

#-------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------#
# Plot catchments totals for each month -----------------------------------

# Recharge
pdf(file.path(dir_out,'CatchmentRechargeByMonth.pdf'), width=8.5, height=11)
catch_rech_split <- split(catch_rech,catch_rech$Date)
temp <- lapply(catch_rech_split, function(subset_data) {

  message("Plotting Recharge for Date: ",subset_data$Date[1])

  # Create a ggplot for the current date
  p <- ggplot(subset_data, aes(fill = total_m3m)) +
    geom_sf() +
    scale_fill_viridis_c() +
    labs(title = paste("Recharge Sum (m^3/month) on", as.character(subset_data$Date[1]))) +
    theme_minimal() +
    guides(fill = guide_colorbar(barheight = 15))

  # Or print the plot to the screen
  print(p)
})
dev.off()
#
# # GW In
# pdf(file.path(dir_out, 'CatchmentGWInByMonth.pdf'), width=8.5, height=11)
# catch_gwin_split <- split(catch_gwin,catch_gwin$Date)
# temp <- lapply(catch_gwin_split, function(subset_data) {
#
#   message("Plotting GW_In for Date: ",subset_data$Date[1])
#
#   # Create a ggplot for the current date
#   p <- ggplot(subset_data, aes(fill = total_m3m)) +
#     geom_sf() +
#     scale_fill_viridis_c() +
#     labs(title = paste("GW In Sum (m^3/month) on", as.character(subset_data$Date[1]))) +
#     theme_minimal() +
#     guides(fill = guide_colorbar(barheight = 15))
#
#   # Or print the plot to the screen
#   print(p)
# })
# dev.off()
#
# # GW->SW Flow
# pdf(file.path(dir_out, 'CatchmentGWSWFlowByMonth.pdf'), width=8.5, height=11)
# catch_flow_split <- split(catch_flow,catch_flow$Date)
# temp <- lapply(catch_flow_split, function(subset_data) {
#
#   message("Plotting GW->SW Flow for Date: ",subset_data$Date[1])
#
#   # Create a ggplot for the current date
#   p <- ggplot(subset_data, aes(fill = total_m3m)) +
#     geom_sf() +
#     scale_fill_viridis_c() +
#     labs(title = paste("GW to SW FLow Sum (m^3/month) on", as.character(subset_data$Date[1]))) +
#     theme_minimal() +
#     guides(fill = guide_colorbar(barheight = 15))
#
#   # Or print the plot to the screen
#   print(p)
# })
# dev.off()
#
# # Sink
# pdf(file.path(dir_out, 'CatchmentSinkByMonth.pdf'), width=8.5, height=11)
# catch_sink_split <- split(catch_sink,catch_sink$Date)
# temp <- lapply(catch_sink_split, function(subset_data) {
#
#   message("Plotting GWR Sink for Date: ",subset_data$Date[1])
#
#   # Create a ggplot for the current date
#   p <- ggplot(subset_data, aes(fill = total_m3m)) +
#     geom_sf() +
#     scale_fill_viridis_c() +
#     labs(title = paste("GWR Sink Sum (m^3/month) on", as.character(subset_data$Date[1]))) +
#     theme_minimal() +
#     guides(fill = guide_colorbar(barheight = 15))
#
#   # Or print the plot to the screen
#   print(p)
# })
# dev.off()
#-------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------#
# Average by Month --------------------------------------------------------

rech_m_average <- catch_rech %>%
  mutate(month = format(Date, "%m")) %>%
  group_by(SubId, month) %>%
  summarize(avg_m3m = mean(total_m3m, na.rm = TRUE))

# gwin_m_average <- catch_gwin %>%
#   mutate(month = format(Date, "%m")) %>%
#   group_by(SubId, month) %>%
#   summarize(avg_m3m = mean(total_m3m, na.rm = TRUE))
#
# flow_m_average <- catch_flow %>%
#   mutate(month = format(Date, "%m")) %>%
#   group_by(SubId, month) %>%
#   summarize(avg_m3m = mean(total_m3m, na.rm = TRUE))
#
# sink_m_average <- catch_sink %>%
#   mutate(month = format(Date, "%m")) %>%
#   group_by(SubId, month) %>%
#   summarize(avg_m3m = mean(total_m3m, na.rm = TRUE))

write.csv(st_drop_geometry(rech_m_average), file.path(dir_out, 'rech_monthly_bySubId_average.csv'))
# write.csv(st_drop_geometry(gwin_m_average), file.path(dir_out, 'gwin_monthly_bySubId_average.csv'))
# write.csv(st_drop_geometry(flow_m_average), file.path(dir_out, 'flow_monthly_bySubId_average.csv'))
# write.csv(st_drop_geometry(sink_m_average), file.path(dir_out, 'sink_monthly_bySubId_average.csv'))

#-------------------------------------------------------------------------------------------------#
