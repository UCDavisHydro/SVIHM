library(RSVP)

#-------------------------------------------------------------------------------------------------#
# Settings ----------------------------------------------------------------

m_to_in <- 1/0.0254

#-- Years to examine
curr_yr <- as.numeric(format(Sys.time(), '%Y'))
prev_yr <- curr_yr - 1

#-- Get WY start/ends
curr_wy <- c(get_model_start(curr_yr), get_model_end(curr_yr))
prev_wy <- c(get_model_start(prev_yr), get_model_end(prev_yr))

# Directory (Created in SVIHM_Input_Files/Updates) - Grabs latest version
update_dir <- latest_dir(data_dir['update_dir','loc'])

#-------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------#
# Import and Subset Data --------------------------------------------------

#-- ET
et_all <- read.csv(file.path(update_dir, 'ref_et.txt'), sep = " ", header=F,
                   col.names = c('ETo_m','ETo_in','Date'))
et_all$Date <- as.Date(et_all$Date, '%d/%m/%Y')

#-- Precip
prcp_all <- read.csv(file.path(update_dir, 'precip.txt'), sep=" ", header=F,
                     col.names = c('precip_m', 'Date'))
prcp_all$precip_in <- prcp_all$precip_m * m_to_in
prcp_all$Date <- as.Date(prcp_all$Date, '%d/%m/%Y')

#-- Subset
et_curr <- subset.DateTwoSided(et_all, curr_wy[1], curr_wy[2], include_end = T)
et_prev <- subset.DateTwoSided(et_all, prev_wy[1], prev_wy[2], include_end = T)
prcp_curr <- subset.DateTwoSided(prcp_all, curr_wy[1], curr_wy[2], include_end = T)
prcp_prev <- subset.DateTwoSided(prcp_all, prev_wy[1], prev_wy[2], include_end = T)

#-------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------#
# Calculate Potential Recharge    ----------------------------------------
rech_curr <- prcp_curr$precip_in - et_curr$ETo_in
rech_prev <- prcp_prev$precip_in - et_prev$ETo_in

rech_curr[rech_curr < 0] <- 0
rech_prev[rech_prev < 0] <- 0

#-------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------#
# Plot  -------------------------------------------------------------------

layout(matrix(c(1,2,3), 1, 3, byrow = TRUE))

# Xlim
mnths <- seq.Date(curr_wy[1], curr_wy[2], by='month')

# Precip
plot.ts_setup(dates = prcp_curr$Date, cumsum(prcp_prev$precip_in),
              xlabel = 'Month', ylabel = 'Cumulative Precipitation (in)',
              xlim_override = mnths, ylim_min_diff = 0)
lines(prcp_curr$Date, cumsum(prcp_curr$precip_in), col='dodgerblue2')
lines(prcp_prev$Date + 365, cumsum(prcp_prev$precip_in), col='goldenrod3')
title('Cumulative Precipitation')

# ET
plot.ts_setup(dates = et_curr$Date, et_prev$ETo_in,
              xlabel = 'Month', ylabel = 'ET (in)',
              xlim_override = mnths, ylim_min_diff = 0)
lines(et_curr$Date, et_curr$ETo_in, col='dodgerblue2')
lines(et_prev$Date + 365, et_prev$ETo_in, col='goldenrod3')
title('ET')


# Cumulative ET ?


#-------------------------------------------------------------------------------------------------#
