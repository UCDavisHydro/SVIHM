library(RSVP)

#-------------------------------------------------------------------------------------------------#
#-- Read in latest SWBM Inputs

# Directory (Created in SVIHM_Input_Files/Updates) - Grabs latest version
update_dir <- latest_dir(data_dir['update_dir','loc'])

flows <- read.table(file.path(update_dir, 'streamflow_input.txt'), sep = '', header=T, stringsAsFactors = F)
flows$Month <- as.Date(flows$Month, format = '%Y-%m-%d')

# Add generic date column for matching
flows$month_year <- format(flows$Month, '%Y-%m')

#-- Resample (downscale) to daily through repetition

# Setup
daily <- data.frame('Date' = seq(from = min(flows$Month), to = max(flows$Month), by = "days"))
daily$month_year <- format(daily$Date, '%Y-%m')

# Match
daily <- merge(daily, flows, by = 'month_year')

# Write
