# 02_BaseUpdate.R
#
#
library(RSVP)
library(lubridate)
library(sf)

# ------------------------------------------------------------------------------------------------#
# Settings ----------------------------------------------------------------------------------------
# Dates
start_year <- 1991 # WY 1991; do not change
end_year   <- as.numeric(format(Sys.Date(), "%Y"))  # Assumes current year

# Directory (Created in SVIHM_Input_Files/Updates) - Grabs latest version
update_dir <- latest_dir(data_dir['update_dir','loc'])


months <- c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

# Create a vector of starting days for each month
start_days <- c(1, 1, 1, 1, 1, 1, 24, 1, 1, 1, 1, 1, 1)

# Create a vector of ending days for each month
end_days <- c(31, 28, 31, 30, 31, 23, 30, 31, 31, 30, 31, 30, 31)

# Create a dataframe
min_flow <- data.frame(
  start = sprintf("%02d-%02d", match(months, month.abb), start_days),
  end = sprintf("%02d-%02d", match(months, month.abb), end_days),
  flow = c(200, 200, 200, 150, 150, 125, 90, 50, 30, 33, 40, 60, 150)
)

outfile <- 'EmFlow_30LCS'
start_lcs_april <- TRUE
lcs_curt <- 0.3

m2_to_acres = 1/4046.856
apn_overlap_threshold = 0.5
exclude_terrible_and_major_overflow_polygons = F

# ------------------------------------------------------------------------------------------------#

# ------------------------------------------------------------------------------------------------#
# Temporal discretization -------------------------------------------------------------------------

model_start_date <- get_model_start(start_year)
model_end_date <- as.Date(basename(update_dir))-1

num_stress_periods <- calc_num_stress_periods(model_start_date, model_end_date)
num_days <- days_in_month_diff(model_start_date, model_end_date)  # current setup: days = time steps

# ------------------------------------------------------------------------------------------------#

# ------------------------------------------------------------------------------------------------#
# Read Flow
fjd <- read.csv(file.path(update_dir, list.files(update_dir, pattern = 'FJ (USGS 11519500)*')),
                stringsAsFactors = F)
fjd$Date <- as.Date(fjd$Date)

# ------------------------------------------------------------------------------------------------#

# ------------------------------------------------------------------------------------------------#
# Find when curtailments start each year:
# First date below the min_flow flow, after June, except 2014 & 2015, when after May
fjd$Year <- year(fjd$Date)
fjd_byyear <- split(fjd, fjd$Year)
firsts <- lapply(fjd_byyear, function(df) {
  y <- df$Year[1]
  first <- NA
  for (i in 1:nrow(min_flow)) {
    mind <- as.Date(paste0(y,'-',min_flow$start[i]))
    maxd <- as.Date(paste0(y,'-',min_flow$end[i]))

    # Skip if this period isn't present in this year
    if (min(df$Date) > mind) { next }

    # Skip if before June! As per Thomas
    if (!(y %in% c(2014,2015)) & (month(mind) < 6)) { next }
    if ((y %in% c(2014,2015)) & (month(mind) < 5)) { next }

    if (min(df[(df$Date >= mind) & (df$Date < maxd),'Flow']) < min_flow$flow[i]) {
      # Found the first curtailment date...
      first <- df[(df$Date >= mind) & (df$Date < maxd),][which(df[(df$Date >= mind) & (df$Date < maxd),'Flow'] < min_flow$flow[i])[1],'Date']
      break
    }
  }
  return(first)
})
# ------------------------------------------------------------------------------------------------#

# ------------------------------------------------------------------------------------------------#
# Create basic curtailment and SW Irrigation files
subws_inflow_filename = file.path(update_dir,"daily_streamflow_input.txt")
subws_irr_inflows <- process_sfr_inflows(model_start_date, model_end_date,
                                         stream_inflow_filename = subws_inflow_filename,
                                         avail_for_irr = T,
                                         scenario_id = current_scenario) # Possibly divide flow into avail and unavail for irr based on flow regime
subws_nonirr_inflows <- process_sfr_inflows(model_start_date, model_end_date,
                                            stream_inflow_filename = subws_inflow_filename,
                                            avail_for_irr = F,
                                            scenario_id = current_scenario) # Possibly divide flow into avail and unavail for irr based on flow regime

# pull reference land cover
poly_tab = read.table(file.path(data_dir["time_indep_dir","loc"],"polygons_table.txt"),
                      header = T)
num_unique_fields = length(unique(poly_tab$SWBM_id))

# generate a stress-period-by-field table (wide format)  for saving to output
curtail_output = swbm_build_field_value_df(nfields = num_unique_fields,
                                     model_start_date = model_start_date,
                                     model_end_date = model_end_date)

# Build 0-curtailment fraction table
field_column_selector = grepl(pattern = "ID", x = colnames(curtail_output))
curtail_output[,field_column_selector] = 0

# Read in LCS fields
lcs_fields_all = read_sf(dsn = file.path(data_dir["ref_data_dir","loc"],"Landuse_LCS2022 app matching_2023.05.16.shp"))

# Process APNs
# For apps with no visual maps, gotta use the APN data
lcs_apns_all = read_sf(dsn = file.path(data_dir["ref_data_dir","loc"],
                                       "LCS 2022 Plans_App matching_2023.05.shp"))
lcs_apns_all = st_transform(x = lcs_apns_all, crs = st_crs(lcs_fields_all))
lcs_apns = lcs_apns_all[lcs_apns_all$NoMap!=0,]
nomap_apps = lcs_apns$NoMap
# remove "2045" and add "20" and "45"
nomap_apps = nomap_apps[nomap_apps!=2045]
nomap_apps = c(nomap_apps, 20, 45)

# Read in the LCS application info tab
lcs_info = read.table(file.path(data_dir["ref_data_dir","loc"], "2022 LCS Field Number Matching_interim.txt"),
                      header = T, sep = "\t", fill =T, fileEncoding = "latin1")
for(i_app in nomap_apps){ #
  print(paste("Finding field overlap fractions for APNs in LCS app. no.",i_app))
  lcs_acres = lcs_info$Acres[lcs_info$Application_Number==i_app]

  if(i_app == 20 | i_app == 45){i_app=2045}

  apn_footprint = lcs_apns[lcs_apns$NoMap==i_app,]
  apn_acres = as.numeric(st_area(apn_footprint))*m2_to_acres
  # Find fields overlapping with apn footprint
  lu_poly_overlap = lcs_fields_all[apn_footprint,]
  lu_poly_overlap$fraction_overlap_apn = NA

  # calculate % of area of each field that overlaps with APN footprint
  for(j in 1:nrow(lu_poly_overlap)){
    field_j = lu_poly_overlap[j,]
    field_apn_intersect = st_intersection(x = field_j, y = apn_footprint)
    field_area_overlap_fraction = as.numeric(st_area(field_apn_intersect) / st_area(field_j))
    lu_poly_overlap$fraction_overlap_apn[j] = field_area_overlap_fraction
  }

  # Assign fields with more than the designated threshold (i.e. 50%) of overlap
  # with the APN footprint to the relevant LCS app number
  assign_these_fields = lu_poly_overlap$Poly_nmbr[lu_poly_overlap$fraction_overlap_apn > apn_overlap_threshold]
  lcs_fields_all$LCS_APP[lcs_fields_all$Poly_nmbr %in% assign_these_fields] = i_app
}

# Now that we've assigned all the fields with their LCS app,
# restrict lcs_fields to just ones with an app number
lcs_fields = lcs_fields_all[!is.na(lcs_fields_all$LCS_APP),]
# exclude terrible overflow and major overflow
if(exclude_terrible_and_major_overflow_polygons == T){
  lcs_fields_excl_major = lcs_fields[!(grepl(pattern = "majoroverflow",
                                             x = lcs_fields$Comments) |
                                         grepl(pattern = "terribleoverflow",
                                               x = lcs_fields$Comments)),]
  # sum(st_area(lcs_fields_excl_major)) * m2_to_acres
  # sort(unique(lcs_fields_excl_major$LCS_APP))
  # not included (no map): 12, 13, 18, 20, 23, 25, 28, 31, 32, 45
  # not included (major or terrible overflow): 15, 30 (small acreage)
  lcs_fields = lcs_fields_excl_major
  # sum(st_area(lcs_fields)) * m2_to_acres  # 18.7k acres relative to 17k reported. Not so bad
}
# sum(st_area(lcs_fields)) * m2_to_acres  # If include major and terrible overflow, 20.9k acres relative to 17k reported. Not so bad


# field list pre-processes from Claire
lcs_fields = lcs_fields_all[!is.na(lcs_fields_all$LCS_APP),]
lcs_fields_colnames = paste0("ID_",lcs_fields$Poly_nmbr)
non_lcs_fields = lcs_fields_all[is.na(lcs_fields_all$LCS_APP),]
# include fields listed as App #0, I think that's a quality control thing
fields_0 = lcs_fields_all[lcs_fields_all$LCS_APP==0 & !is.na(lcs_fields_all$LCS_APP),]
non_lcs_fields = rbind(non_lcs_fields, fields_0)
non_lcs_field_ids = non_lcs_fields$Poly_nmbr
# curtail 100% of all water use on non-lcs fields
non_lcs_fields_colnames = paste0("ID_",non_lcs_fields$Poly_nmbr)

# ------------------------------------------------------------------------------------------------#
# Loop over years (again!) creating curtailments
for (i in 1:length(firsts)) {
  first <- firsts[[i]]
  y <- as.numeric(names(firsts)[i])  #year(first)

  # Set GW curtailments
  if (start_lcs_april & (!is.na(first))) {
    lcs_months = curtail_output$Stress_Period >= as.Date(paste0(y,"-04-01")) & curtail_output$Stress_Period < as.Date(paste0(y,"-12-31"))
    curtail_months = curtail_output$Stress_Period >= first & curtail_output$Stress_Period < as.Date(paste0(y,"-12-31"))
    curtail_month_1 <- curtail_output$Stress_Period == make_date(y, month(first), 1)
    proportion <- 1
    if (month(first) < 11) {
      curtail_output[lcs_months,       lcs_fields_colnames] = lcs_curt
      curtail_output[curtail_month_1,    lcs_fields_colnames] = lcs_curt * proportion
    }
    curtail_output[curtail_months, non_lcs_fields_colnames] = 1
    curtail_output[curtail_month_1,non_lcs_fields_colnames] = 0
  } else if (!is.na(first)) {
    curtail_months = curtail_output$Stress_Period >= first & curtail_output$Stress_Period < as.Date(paste0(y,"-12-31"))
    curtail_month_1 <- curtail_output$Stress_Period == make_date(y, month(first), 1)
    proportion <- as.numeric(((days_in_month(first) - day(first)) + 1) / days_in_month(first))  # Perfect foresight, starts exact day of low flow
    curtail_output[curtail_months,    lcs_fields_colnames] = lcs_curt
    curtail_output[curtail_month_1,    lcs_fields_colnames] = lcs_curt * proportion
    curtail_output[curtail_months, non_lcs_fields_colnames] = 1
    curtail_output[curtail_month_1,non_lcs_fields_colnames] = 0 # Handled via irr flows adjustment
  }

  if (!is.na(first)) {
    # Set SW curtailments
    subws_nonirr_inflows <- move_inflows(subws_nonirr_inflows, subws_irr_inflows, date_start = first, as.Date(paste0(y,"-12-31")))
    subws_irr_inflows <- set_inflows(subws_irr_inflows, date_start = first, as.Date(paste0(y,"-12-31")), value = 0.0)
  }

  # Return string
  message(paste('Year:',y,"|",'Curtailment Starts on:',first,"| Non-LCS GW Curtailment is",round(proportion*100),"% of the first month"))
}

# ------------------------------------------------------------------------------------------------#
# Write outputs
write_SWBM_SFR_inflow_files(subws_irr_inflows, update_dir, paste0("subwatershed_irrigation_inflows_", outfile,".txt"))
write_SWBM_SFR_inflow_files(subws_nonirr_inflows, update_dir, paste0("subwatershed_nonirrigation_inflows_", outfile,".txt"))

curt_filename = paste0("curtailment_fractions_", outfile,".txt")
write.table(curtail_output, file = file.path(update_dir, curt_filename),
            sep = "  ", quote = FALSE, col.names = TRUE, row.names = FALSE)
