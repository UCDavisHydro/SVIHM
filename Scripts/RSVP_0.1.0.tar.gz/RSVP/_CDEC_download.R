library(RSVP)
library(cder)

#-------------------------------------------------------------------------------------------------#
#-- Setup
# Dates
start_year <- 2020 # WY 1991; do not change
end_year   <- as.numeric(format(Sys.Date(), "%Y"))  # Assumes current year
model_start_date <- get_model_start(start_year)
model_end_date <- as.Date(floor_date(Sys.Date(), 'month')-1)

gauges <- c('FCC', 'SCK', 'SGN')
gauge_files <- c(file.path(data_dir['sf_reg_dir','loc'],
                           c('FrenchCreek.csv','Shackleford.csv')),
                 NA)
fcc_adj <- 2825.60  # After Feb 8, 2021 06:00
sck_adj <- 2683.11  # After Feb 8, 2021 06:00

#idk a table?
trib_curves <- data.frame('gauge'=gauges,
                        'sensor'=c(1,1,20),
                        'NAVD88_Adj'=c(fcc_adj,sck_adj, NA),
                        'NAVD88_Adj_date'=c(rep(as.POSIXct('2021-02-08 06:00'),2), NA),
                        'curve_Cr'=c(26.25007261, 47.6212389, NA),
                        'curve_alpha'=c(2835.75, 2684.66, NA),
                        'curve_beta'=c(3.575758046, 2.240160767, NA),
                        'curve_file'=gauge_files)
#-------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------#
#-- Download
gdata <- cdec_query(trib_curves[,'gauge'],
                    trib_curves[,'sensor'],
                    start.date=model_start_date,
                    end.date = model_end_date)

#-- Append manual download
sgn_man <- read.csv(file.path(data_dir['sf_reg_dir','loc'],'SGN_FLOW_ManualDownload.csv'))
#-------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------#
#-- Curve Functions

stage2discharge_curve <- function(stages, curve_Cr, curve_alpha, curve_beta) {
  curve_Cr*(stages - curve_alpha)^curve_beta
}

gauge_datum_adj <- function(values, dates, before_date, add_val) {
  values[dates < before_date] = values[dates < before_date] + add_val
  return(values)
}

#-------------------------------------------------------------------------------------------------#

aggregate.Date <- function(dates, values, interval, date_col='Date', FUN, ...) {

  # Pick date format code
  if (interval=='m') {
    fmt <- '%Y-%m'
  } else if (interval=='d') {
    fmt <- '%Y-%m-%d'
  } else if (interval=='y') {
    fmt <- '%Y'
  } else {
    stop('Invalid interval (d - Day, m - Month, y - Year)')
  }

  aggie <- do.call(data.frame, aggregate(values, by=list(format(dates, fmt)), FUN=FUN, ...))
  # "Fix" column names
  names(aggie)[1] <- date_col
  names(aggie)[2:ncol(aggie)] <- gsub('x.', '', names(aggie)[2:ncol(aggie)])

  return(aggie)
}

#-------------------------------------------------------------------------------------------------#
#-- Read in curves
cdata <- lapply(na.omit(trib_curves[,'curve_file']), read.csv)

#-------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------#
#-- Estimate Flow & Convert to Monthly
cdec_tribs = list()
for (i in 1:nrow(trib_curves)) {
  # Subset
  tdf <- as.data.frame(gdata[gdata$StationID == trib_curves[i,'gauge'] &
                             gdata$SensorNumber == trib_curves[i,'sensor'],])

  # If sensor is 1, use curve to translate stage to flow
  if (trib_curves[i,'sensor']==1) {
    tdf$Value <- gauge_datum_adj(tdf$Value, tdf$DateTime, trib_curves[i,'NAVD88_Adj_date'], trib_curves[i,'NAVD88_Adj'])
    tdf$cfs <- approx(cdata[[i]]$Stage_ft, cdata[[i]]$Flow_cfs, xout=tdf$Value)$y
    # Cutoff below lowest stage
    tdf$cfs[tdf$Value < min(cdata[[i]]$Stage_ft)] <- 0.0
  } else {
    # Just rename col
    names(tdf)[names(tdf)=='Value'] = 'cfs'
  }
  # Convert to Acre-ft
  tdf$AF <- tdf$cfs * 86400 * 2.2957e-5  # cfs to cfd, to acre-ft 2.29569e-5

  # Aggregate to daily
  dtdf <- aggregate.Date(tdf$DateTime, tdf$cfs, interval = 'd', FUN = mean)

}
test <- lapply(cdec_tribs, FUN=gauge_monthly_prep)
#-------------------------------------------------------------------------------------------------#

# PRECIP EXPERIMENT 5.8/2023
gdata <- cdec_query('FJN',
                    2,
                    start.date=model_start_date,
                    end.date = model_end_date)
ndata <- download_meteo_data(c('USC00043182'), model_start_date, model_end_date, datatypeid = "all")
edata <- download_meteo_data(c('USC00042899'), model_start_date, model_end_date, datatypeid = "all")

